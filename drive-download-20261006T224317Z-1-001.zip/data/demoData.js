/* =========================================================
   LukApp · demoData.js
   Datos iniciales para trabajar sin API.
   ========================================================= */

import {
    getItem,
    setItem,
    getCurrentUser,
    getMovements,
    getGoals,
    getSettings,
    STORAGE_KEYS
} from '../js/services/storageService.js';

const DEMO_USER = {
    id: 1,
    name: 'Daniel',
    lastName: 'Gutiérrez',
    email: 'usuario@lukapp.com',
    plan: 'Premium',
    avatar: null
};

const DEMO_MOVEMENTS = [
    { id: 1, description: 'Salario mensual', type: 'ingreso', category: 'Ingreso', date: '2026-09-25', amount: 4200000, status: 'completado' },
    { id: 2, description: 'Proyecto freelance', type: 'ingreso', category: 'Freelance', date: '2026-09-22', amount: 850000, status: 'completado' },
    { id: 3, description: 'Supermercado', type: 'gasto', category: 'Alimentación', date: '2026-09-20', amount: 248000, status: 'completado' },
    { id: 4, description: 'Arriendo', type: 'gasto', category: 'Vivienda', date: '2026-09-18', amount: 1200000, status: 'completado' },
    { id: 5, description: 'Transporte', type: 'gasto', category: 'Transporte', date: '2026-09-17', amount: 186000, status: 'completado' },
    { id: 6, description: 'Internet', type: 'gasto', category: 'Servicios', date: '2026-09-15', amount: 95000, status: 'completado' },
    { id: 7, description: 'Netflix', type: 'gasto', category: 'Entretenimiento', date: '2026-09-12', amount: 31900, status: 'completado' },
    { id: 8, description: 'Restaurante', type: 'gasto', category: 'Alimentación', date: '2026-09-11', amount: 72000, status: 'completado' },
    { id: 9, description: 'Venta de producto', type: 'ingreso', category: 'Ventas', date: '2026-09-09', amount: 350000, status: 'completado' },
    { id: 10, description: 'Curso online', type: 'gasto', category: 'Educación', date: '2026-09-07', amount: 120000, status: 'completado' },
    { id: 11, description: 'Farmacia', type: 'gasto', category: 'Salud', date: '2026-09-04', amount: 64000, status: 'completado' },
    { id: 12, description: 'Taxi', type: 'gasto', category: 'Transporte', date: '2026-09-03', amount: 28000, status: 'completado' }
];

const DEMO_GOALS = [
    { id: 1, name: 'Viaje a Europa', icon: '✈', target: 6000000, saved: 2400000, deadline: '2027-06-30', color: 'var(--warning-color)' },
    { id: 2, name: 'Computador', icon: '💻', target: 4500000, saved: 3330000, deadline: '2027-02-15', color: 'var(--primary-color)' },
    { id: 3, name: 'Fondo de emergencia', icon: '🛡', target: 3000000, saved: 1050000, deadline: '2027-12-31', color: 'var(--info-color)' }
];

const DEMO_SETTINGS = {
    currency: 'COP',
    notifications: {
        financialSummary: true,
        goals: true,
        spendingAlerts: true,
        updates: false
    },
    appearance: {
        theme: 'light',
        animations: true
    },
    security: {
        twoFactorEnabled: false,
        passwordHash: null
    }
};

export function ensureDemoData() {
    if (!getCurrentUser()) setItem(STORAGE_KEYS.USER, DEMO_USER);
    if (!getMovements().length) setItem(STORAGE_KEYS.MOVEMENTS, DEMO_MOVEMENTS);
    if (!getGoals().length) setItem(STORAGE_KEYS.GOALS, DEMO_GOALS);

    if (!Object.keys(getSettings()).length) {
        setItem(STORAGE_KEYS.SETTINGS, DEMO_SETTINGS);
    }

    if (!Array.isArray(getItem(STORAGE_KEYS.NOTIFICATIONS))) {
        setItem(STORAGE_KEYS.NOTIFICATIONS, [
            {
                id: 'welcome',
                title: 'Bienvenido a LukApp',
                message: 'Tu panel financiero ya está listo para usar.',
                type: 'info',
                read: false,
                createdAt: new Date().toISOString()
            }
        ]);
    }
}

export { DEMO_USER, DEMO_MOVEMENTS, DEMO_GOALS, DEMO_SETTINGS };
