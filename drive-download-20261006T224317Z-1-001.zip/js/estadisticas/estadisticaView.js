/* =========================================================
   LukApp · estadisticaView.js
   ========================================================= */

let categoryChart = null;
let comparisonChart = null;

export function renderStatistics(data) {
    setText('kpiTopCategoria', data.topCategory);
    setText('kpiPromedioGasto', currency(data.averageExpense));
    setText('kpiRatioAhorro', `${data.savingsRatio.toFixed(1)}%`);

    renderCategoryBreakdown(data.breakdown);
    renderCharts(data);
}

export function renderCharts(data) {
    if (typeof Chart === 'undefined') {
        showChartError();
        return;
    }

    const categories = data.breakdown.map(item => item.category);
    const categoryValues = data.breakdown.map(item => item.total);

    const categoriesCanvas = document.getElementById('chartCategorias');
    const comparisonCanvas = document.getElementById('chartComparativa');

    if (categoryChart) categoryChart.destroy();
    if (comparisonChart) comparisonChart.destroy();

    if (categoriesCanvas) {
        categoryChart = new Chart(categoriesCanvas, {
            type: 'doughnut',
            data: {
                labels: categories.length ? categories : ['Sin datos'],
                datasets: [{
                    data: categoryValues.length ? categoryValues : [1]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' },
                    tooltip: {
                        callbacks: {
                            label: context => `${context.label}: ${currency(context.raw)}`
                        }
                    }
                }
            }
        });
    }

    if (comparisonCanvas) {
        comparisonChart = new Chart(comparisonCanvas, {
            type: 'bar',
            data: {
                labels: data.monthly.map(item => item.label),
                datasets: [
                    { label: 'Ingresos', data: data.monthly.map(item => item.income) },
                    { label: 'Gastos', data: data.monthly.map(item => item.expense) }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => formatCompactCurrency(value)
                        }
                    }
                }
            }
        });
    }
}

function renderCategoryBreakdown(items) {
    const list = document.getElementById('categoryBreakdownList');
    if (!list) return;

    if (!items.length) {
        list.innerHTML = '<li class="empty-state">No hay gastos suficientes para generar un desglose.</li>';
        return;
    }

    let html = '';
    const colors = ['#FFD233', '#3B82F6', '#E04848', '#F59E0B', '#1FA36A', '#9A9A9A'];
    
    items.forEach((item, index) => {
        const color = colors[index % colors.length];
        
        html += `
            <li class="breakdown-item" style="--category-color:${color}">
                <span class="breakdown-item__rank">${index + 1}</span>
                <span class="breakdown-item__name">
                    <span class="breakdown-item__dot"></span>
                    ${escapeHTML(item.category)}
                </span>
                <span class="breakdown-item__bar progress-track">
                    <span class="progress-fill" style="width:${item.percentage}%"></span>
                </span>
                <span class="breakdown-item__percent">${item.percentage.toFixed(1)}%</span>
                <span class="breakdown-item__amount negative">-${currency(item.total)}</span>
            </li>
        `;
    });
    
    list.innerHTML = html;
}

function showChartError() {
    document.querySelectorAll('.chart-wrapper').forEach(wrapper => {
        wrapper.insertAdjacentHTML('beforeend', '<p class="text-muted">No fue posible cargar los gráficos.</p>');
    });
}

function currency(value) {
    return Number(value || 0).toLocaleString('es-CO', {
        style: 'currency', currency: 'COP', maximumFractionDigits: 0
    });
}

function formatCompactCurrency(value) {
    return new Intl.NumberFormat('es-CO', {
        notation: 'compact', maximumFractionDigits: 1
    }).format(value);
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function escapeHTML(value) {
    return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}