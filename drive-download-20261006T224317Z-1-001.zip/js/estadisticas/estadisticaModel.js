/* =========================================================
   LukApp · estadisticaModel.js
   ========================================================= */

import { getMovements } from '../services/storageService.js';

export function getStatistics(period = 'historico') {
    const movements = getMovements();
    
    // LÓGICA CORREGIDA: Datos de transacciones canceladas no son viables financieramente
    const validMovements = movements.filter(item => item.status !== 'cancelado');
    const scoped = filterByPeriod(validMovements, period);

    const expenses = scoped.filter(item => item.type === 'gasto');
    const incomes = scoped.filter(item => item.type === 'ingreso');

    const expenseTotal = expenses.reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const incomeTotal = incomes.reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const savings = incomeTotal - expenseTotal;

    const categoryTotals = expenses.reduce((map, item) => {
        const category = item.category || 'Otros';
        map[category] = (map[category] || 0) + Number(item.amount || 0);
        return map;
    }, {});

    const breakdown = Object.entries(categoryTotals)
        .map(([category, total]) => ({
            category,
            total,
            percentage: expenseTotal ? (total / expenseTotal) * 100 : 0
        }))
        .sort((a, b) => b.total - a.total);

    const topCategory = breakdown[0]?.category || '--';
    const averageExpense = expenses.length ? expenseTotal / expenses.length : 0;
    const savingsRatio = incomeTotal ? (savings / incomeTotal) * 100 : 0;

    return {
        period,
        movements: scoped,
        incomeTotal,
        expenseTotal,
        savings,
        averageExpense,
        savingsRatio,
        topCategory,
        breakdown,
        monthly: buildMonthlyData(scoped)
    };
}

function filterByPeriod(movements, period) {
    if (period !== 'mes_actual') return movements;
    
    // LÓGICA CORREGIDA: Mapear "Este mes" con la fecha de HOY en el calendario
    const now = new Date();
    const prefix = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    
    return movements.filter(item => item.date.startsWith(prefix));
}

function buildMonthlyData(movements) {
    const months = [];
    
    // LÓGICA CORREGIDA: El rango de 6 meses siempre retrocede a partir del mes actual
    const baseDate = new Date(); 

    for (let i = 5; i >= 0; i--) {
        const date = new Date(baseDate.getFullYear(), baseDate.getMonth() - i, 1);
        const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        months.push({
            key,
            label: date.toLocaleDateString('es-CO', { month: 'short' }),
            income: 0,
            expense: 0
        });
    }

    movements.forEach(item => {
        const month = months.find(m => m.key === item.date.slice(0, 7));
        if (!month) return;
        if (item.type === 'ingreso') month.income += Number(item.amount || 0);
        else month.expense += Number(item.amount || 0);
    });

    return months;
}