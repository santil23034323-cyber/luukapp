/* =========================================================
   LukApp · estadisticaController.js
   ========================================================= */

import { getStatistics } from './estadisticaModel.js';
import { renderStatistics } from './estadisticaView.js';

const state = { period: 'historico' };

document.addEventListener('DOMContentLoaded', initializeStatistics);

document.addEventListener('lukapp:data-changed', () => render());

function initializeStatistics() {
    const select = document.getElementById('selectPeriodo');

    if (select) {
        state.period = select.value || 'historico';
        select.addEventListener('change', event => {
            state.period = event.target.value;
            render();
        });
    }

    render();
}

function render() {
    renderStatistics(getStatistics(state.period));
}
