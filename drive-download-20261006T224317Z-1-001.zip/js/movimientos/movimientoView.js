/* =========================================================
   LukApp · movimientoView.js
   ========================================================= */

export function renderSummary(totals, count) {
    setText('kpiIngresos', `+${currency(totals.income)}`);
    setText('kpiGastos', `-${currency(totals.expense)}`);
    setText('kpiBalance', currency(totals.income - totals.expense));
    setText('recordsCount', `${count} ${count === 1 ? 'registro encontrado' : 'registros encontrados'}`);
}

export function renderTable(movements) {
    const body = document.getElementById('movimientosTableBody');
    if (!body) return;

    if (!movements.length) {
        body.innerHTML = `<tr><td colspan="7" class="empty-state">No se encontraron movimientos.</td></tr>`;
        return;
    }

    let html = '';
    movements.forEach(item => {
        const sign = item.type === 'ingreso' ? '+' : '-';
        const iconType = item.type === 'ingreso' ? 'icon-income' : 'icon-expense';
        const iconChar = item.type === 'ingreso' ? '↗' : '↘';

        html += `
            <tr>
                <td class="th-checkbox"><input type="checkbox" class="row-checkbox" data-id="${escapeAttr(item.id)}"></td>
                <td>
                    <div class="cell-description">
                        <span class="tx-icon ${iconType}">${iconChar}</span>
                        <span class="cell-description__text">${escapeHTML(item.description)}</span>
                    </div>
                </td>
                <td><span class="badge-category">${escapeHTML(item.category)}</span></td>
                <td class="cell-date">${formatDate(item.date)}</td>
                <td class="amount-cell ${item.type === 'ingreso' ? 'positive' : 'negative'}">${sign}${currency(item.amount)}</td>
                <td><span class="status-pill ${statusClass(item.status)}">${escapeHTML(item.status)}</span></td>
                <td class="text-right">
                    <div style="display:flex; justify-content:flex-end; gap:4px;">
                        <button type="button" class="btn-icon-sm" data-action="edit" data-id="${escapeAttr(item.id)}" aria-label="Editar" title="Editar">✏️</button>
                        <button type="button" class="btn-icon-sm" data-action="delete" data-id="${escapeAttr(item.id)}" aria-label="Eliminar" title="Eliminar">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    });
    body.innerHTML = html;
}

export function renderPagination(currentPage, totalPages, total, start, end) {
    const info = document.getElementById('paginationInfo');
    const controls = document.getElementById('paginationControls');

    if (info) info.textContent = total ? `Mostrando ${start}-${end} de ${total}` : 'Mostrando 0 de 0';
    if (!controls) return;

    controls.innerHTML = '';
    for (let page = 1; page <= totalPages; page++) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `page-btn ${page === currentPage ? 'active' : ''}`;
        button.dataset.page = String(page);
        button.textContent = String(page);
        controls.appendChild(button);
    }
}

export function openMovementModal(movement = null) {
    closeMovementModal();

    const modal = document.createElement('div');
    modal.className = 'modal-backdrop';
    modal.id = 'movementModal';
    
    // LÓGICA CORREGIDA: Se añade el campo Select para "Estado" que no existía.
    modal.innerHTML = `
        <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="movementModalTitle">
            <div class="modal-header">
                <div>
                    <span class="section-eyebrow">Registro financiero</span>
                    <h2 id="movementModalTitle">${movement ? 'Editar movimiento' : 'Nuevo movimiento'}</h2>
                </div>
                <button type="button" class="btn-icon-sm" id="closeMovementModal" aria-label="Cerrar">×</button>
            </div>
            <form id="movementForm" class="modal-form">
                <div class="movement-type-tabs">
                    <button type="button" class="tab-btn ${movement?.type !== 'ingreso' ? 'active' : ''}" data-type="gasto">Gasto</button>
                    <button type="button" class="tab-btn ${movement?.type === 'ingreso' ? 'active' : ''}" data-type="ingreso">Ingreso</button>
                </div>
                <input type="hidden" name="type" value="${escapeAttr(movement?.type || 'gasto')}">
                <div class="input-group"><label for="movementDescription">Descripción</label><input id="movementDescription" name="description" maxlength="80" required value="${escapeAttr(movement?.description || '')}" placeholder="Ej. Mercado del mes"></div>
                <div class="modal-grid">
                    <div class="input-group"><label for="movementCategory">Categoría</label><select id="movementCategory" name="category" required>${categoryOptions(movement?.category)}</select></div>
                    <div class="input-group"><label for="movementAmount">Monto</label><input id="movementAmount" name="amount" type="number" min="0" step="1" required value="${escapeAttr(movement?.amount || '')}" placeholder="0"></div>
                </div>
                <div class="modal-grid">
                    <div class="input-group">
                        <label for="movementStatus">Estado</label>
                        <select id="movementStatus" name="status" required>
                            <option value="completado" ${movement?.status === 'completado' ? 'selected' : ''}>Completado</option>
                            <option value="pendiente" ${movement?.status === 'pendiente' ? 'selected' : ''}>Pendiente</option>
                            <option value="cancelado" ${movement?.status === 'cancelado' ? 'selected' : ''}>Cancelado</option>
                        </select>
                    </div>
                    <div class="input-group"><label for="movementDate">Fecha</label><input id="movementDate" name="date" type="date" required value="${escapeAttr(movement?.date || today())}"></div>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn-secondary" id="cancelMovementModal">Cancelar</button>
                    <button type="submit" class="btn-primary">${movement ? 'Guardar cambios' : 'Agregar movimiento'}</button>
                </div>
            </form>
        </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('#closeMovementModal').addEventListener('click', closeMovementModal);
    modal.querySelector('#cancelMovementModal').addEventListener('click', closeMovementModal);
    modal.addEventListener('click', event => {
        if (event.target === modal) closeMovementModal();
    });

    modal.querySelectorAll('.movement-type-tabs .tab-btn').forEach(button => {
        button.addEventListener('click', () => {
            modal.querySelectorAll('.movement-type-tabs .tab-btn').forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            modal.querySelector('[name="type"]').value = button.dataset.type;
            modal.querySelector('#movementCategory').innerHTML = categoryOptions('', button.dataset.type);
        });
    });

    return modal.querySelector('#movementForm');
}

export function closeMovementModal() {
    document.getElementById('movementModal')?.remove();
}

export function getMovementFormData(form) {
    return Object.fromEntries(new FormData(form).entries());
}

function categoryOptions(selected = '', type = 'gasto') {
    const categories = type === 'ingreso'
        ? ['Ingreso', 'Salario', 'Freelance', 'Ventas', 'Otros']
        : ['Alimentación', 'Vivienda', 'Transporte', 'Servicios', 'Educación', 'Entretenimiento', 'Salud', 'Compras', 'Otros'];

    return categories.map(category => `<option value="${escapeAttr(category)}" ${category === selected ? 'selected' : ''}>${escapeHTML(category)}</option>`).join('');
}

function statusClass(status) {
    if (status === 'completado') return 'status-completed';
    if (status === 'pendiente') return 'status-pending';
    return 'status-cancelled';
}

function currency(value) {
    return Number(value || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 });
}

function formatDate(value) {
    return new Date(value + 'T00:00:00').toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' });
}

function today() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function setText(id, value) {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
}

function escapeHTML(value) {
    return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}

function escapeAttr(value) {
    return escapeHTML(value);
}