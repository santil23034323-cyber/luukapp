/* =========================================================
   LukApp · movimientoModel.js
   ========================================================= */

import {
    getMovements,
    addMovement,
    updateMovement,
    deleteMovement,
    deleteMovements
} from '../services/storageService.js';

export function getAllMovements() {
    return [...getMovements()].sort((a, b) => new Date(b.date) - new Date(a.date));
}

export function getMovementById(id) {
    return getAllMovements().find(item => String(item.id) === String(id)) || null;
}

export function createMovement(data) {
    const movement = {
        id: crypto.randomUUID?.() || `m-${Date.now()}`,
        description: data.description,
        type: data.type,
        category: data.category,
        date: data.date,
        amount: Number(data.amount),
        status: data.status || 'completado'
    };

    return addMovement(movement) ? movement : null;
}

export function editMovement(id, data) {
    const changes = {
        description: data.description,
        type: data.type,
        category: data.category,
        date: data.date,
        amount: Number(data.amount),
        status: data.status || 'completado'
    };

    return updateMovement(id, changes);
}

export function removeMovement(id) {
    return deleteMovement(id);
}

export function removeMovements(ids) {
    return deleteMovements(ids);
}

export function getMovementTotals(movements = getAllMovements()) {
    return movements.reduce((total, movement) => {
        // LÓGICA CORREGIDA: Excluir dinero ficticio
        if (movement.status === 'cancelado') return total;
        
        const amount = Number(movement.amount || 0);
        if (movement.type === 'ingreso') total.income += amount;
        else total.expense += amount;
        return total;
    }, { income: 0, expense: 0 });
}