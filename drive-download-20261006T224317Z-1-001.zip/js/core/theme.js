/* =========================================================
   LukApp · theme.js
   ========================================================= */

const THEMES = { LIGHT: 'light', DARK: 'dark' };

function getSavedTheme() {
    // LÓGICA CORREGIDA: Sincronizar desde la base general de settings para prevenir FOUC
    try {
        const rawSettings = localStorage.getItem('lukapp_settings');
        if (rawSettings) {
            const settings = JSON.parse(rawSettings);
            if (settings && settings.appearance && settings.appearance.theme) {
                return settings.appearance.theme;
            }
        }
    } catch (e) {}

    // Fallback por si settings no está inicializado
    const saved = localStorage.getItem('lukapp_theme');
    if (saved === THEMES.DARK || saved === THEMES.LIGHT) return saved;

    return window.matchMedia?.('(prefers-color-scheme: dark)').matches
        ? THEMES.DARK
        : THEMES.LIGHT;
}

export function applyTheme(theme, persist = true) {
    const selected = theme === THEMES.DARK ? THEMES.DARK : THEMES.LIGHT;

    document.documentElement.dataset.theme = selected;

    if (persist) {
        // Asegurar que ambas claves persistan de forma síncrona
        localStorage.setItem('lukapp_theme', selected);
        try {
            const rawSettings = localStorage.getItem('lukapp_settings');
            const settings = rawSettings ? JSON.parse(rawSettings) : {};
            if (!settings.appearance) settings.appearance = {};
            settings.appearance.theme = selected;
            localStorage.setItem('lukapp_settings', JSON.stringify(settings));
        } catch (e) {}
    }

    updateThemeButton(selected);
}

export function toggleTheme() {
    const current = document.documentElement.dataset.theme || THEMES.LIGHT;
    applyTheme(current === THEMES.DARK ? THEMES.LIGHT : THEMES.DARK);
}

function updateThemeButton(theme) {
    const button = document.getElementById('btnTheme');

    if (!button) return;

    const dark = theme === THEMES.DARK;
    button.textContent = dark ? '☀' : '◐';
    button.setAttribute('aria-label', dark ? 'Cambiar a tema claro' : 'Cambiar a tema oscuro');
    button.setAttribute('title', dark ? 'Tema claro' : 'Tema oscuro');
}

export function initializeTheme() {
    applyTheme(getSavedTheme(), true);

    const button = document.getElementById('btnTheme');
    if (button && !button.dataset.bound) {
        button.dataset.bound = 'true';
        button.addEventListener('click', toggleTheme);
    }
}

/* Evita un parpadeo visual antes del DOM. */
applyTheme(getSavedTheme(), false);

document.addEventListener('DOMContentLoaded', initializeTheme);