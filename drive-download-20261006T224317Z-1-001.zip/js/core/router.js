/* =========================================================
   LukApp · router.js
   Punto de entrada: decide qué vista cargar.
   ========================================================= */

import { getSession } from '../services/storageService.js';

const destination = getSession() ? 'dashboard.html' : 'login.html';
window.location.replace(destination);
