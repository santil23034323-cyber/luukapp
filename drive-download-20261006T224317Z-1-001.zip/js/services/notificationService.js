/* =========================================================
   LukApp · notificationService.js
   ========================================================= */

import {
    getItem,
    setItem,
    STORAGE_KEYS
} from './storageService.js';

export function getNotifications() {
    const data = getItem(STORAGE_KEYS.NOTIFICATIONS);
    return Array.isArray(data) ? data : [];
}

export function getUnreadNotifications() {
    return getNotifications().filter(item => !item.read);
}

export function getUnreadCount() {
    return getUnreadNotifications().length;
}

export function createNotification(data = {}) {
    const notification = {
        id: data.id || `notification-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        title: data.title || 'Notificación',
        message: data.message || '',
        type: data.type || 'info',
        read: Boolean(data.read),
        createdAt: data.createdAt || new Date().toISOString(),
        link: data.link || null
    };

    const notifications = [notification, ...getNotifications()].slice(0, 50);
    setItem(STORAGE_KEYS.NOTIFICATIONS, notifications);
    emit('created', notification);
    return notification;
}

export function markAsRead(id) {
    const notifications = getNotifications();
    const item = notifications.find(notification => String(notification.id) === String(id));
    if (!item) return false;

    item.read = true;
    setItem(STORAGE_KEYS.NOTIFICATIONS, notifications);
    emit('updated', item);
    return true;
}

export function markAllAsRead() {
    const notifications = getNotifications().map(item => ({ ...item, read: true }));
    setItem(STORAGE_KEYS.NOTIFICATIONS, notifications);
    emit('all-read');
    return true;
}

export function deleteNotification(id) {
    const filtered = getNotifications().filter(item => String(item.id) !== String(id));
    setItem(STORAGE_KEYS.NOTIFICATIONS, filtered);
    emit('deleted', id);
    return true;
}

export function clearNotifications() {
    setItem(STORAGE_KEYS.NOTIFICATIONS, []);
    emit('cleared');
    return true;
}

export function notifyGoalReached(goalName) {
    return createNotification({
        title: 'Meta alcanzada',
        message: `Has alcanzado tu meta "${goalName}".`,
        type: 'success'
    });
}

export function notifySpendingAlert(category, amount) {
    return createNotification({
        title: 'Alerta de gasto',
        message: `Tus gastos en ${category} han alcanzado $${Number(amount).toLocaleString('es-CO')}.`,
        type: 'warning'
    });
}

export function notifyIncome(amount, description = 'Nuevo ingreso') {
    return createNotification({
        title: 'Nuevo ingreso',
        message: `${description}: +$${Number(amount).toLocaleString('es-CO')}.`,
        type: 'success'
    });
}

export function notifyExpense(amount, description = 'Nuevo gasto') {
    return createNotification({
        title: 'Nuevo gasto',
        message: `${description}: -$${Number(amount).toLocaleString('es-CO')}.`,
        type: 'info'
    });
}

function emit(action, data = null) {
    document.dispatchEvent(new CustomEvent('lukapp:notification', {
        detail: {
            action,
            data,
            unreadCount: getUnreadCount()
        }
    }));
}
