/* =========================================================
   LukApp · storageService.js
   ========================================================= */

export const STORAGE_KEYS = {
    SESSION: 'lukapp_session',
    USER: 'lukapp_user',
    THEME: 'lukapp_theme',
    MOVEMENTS: 'lukapp_movements',
    GOALS: 'lukapp_goals',
    SETTINGS: 'lukapp_settings',
    NOTIFICATIONS: 'lukapp_notifications'
};

function getStorage(useSession = false) {
    return useSession ? window.sessionStorage : window.localStorage;
}

export function getItem(key, useSession = false) {
    try {
        const raw = getStorage(useSession).getItem(key);
        return raw === null ? null : JSON.parse(raw);
    } catch (error) {
        console.error(`LukApp · Error leyendo "${key}"`, error);
        return null;
    }
}

export function setItem(key, value, useSession = false) {
    try {
        getStorage(useSession).setItem(key, JSON.stringify(value));
        return true;
    } catch (error) {
        console.error(`LukApp · Error guardando "${key}"`, error);
        return false;
    }
}

export function removeItem(key, useSession = false) {
    try {
        getStorage(useSession).removeItem(key);
        return true;
    } catch (error) {
        console.error(`LukApp · Error eliminando "${key}"`, error);
        return false;
    }
}

export function hasItem(key, useSession = false) {
    return getStorage(useSession).getItem(key) !== null;
}

export function clearStorage(useSession = false) {
    try {
        getStorage(useSession).clear();
        return true;
    } catch (error) {
        console.error('LukApp · Error limpiando almacenamiento', error);
        return false;
    }
}

export function getSession() {
    return getItem(STORAGE_KEYS.SESSION) || getItem(STORAGE_KEYS.SESSION, true);
}

export function setSession(session, remember = true) {
    removeItem(STORAGE_KEYS.SESSION);
    removeItem(STORAGE_KEYS.SESSION, true);
    return setItem(STORAGE_KEYS.SESSION, session, !remember);
}

export function clearSession() {
    removeItem(STORAGE_KEYS.SESSION);
    removeItem(STORAGE_KEYS.SESSION, true);
}

export function getCurrentUser() {
    return getItem(STORAGE_KEYS.USER) || getItem(STORAGE_KEYS.USER, true);
}

export function setCurrentUser(user, remember = true) {
    removeItem(STORAGE_KEYS.USER);
    removeItem(STORAGE_KEYS.USER, true);
    return setItem(STORAGE_KEYS.USER, user, !remember);
}

export function getMovements() {
    const data = getItem(STORAGE_KEYS.MOVEMENTS);
    return Array.isArray(data) ? data : [];
}

export function setMovements(movements) {
    return Array.isArray(movements) && setItem(STORAGE_KEYS.MOVEMENTS, movements);
}

export function addMovement(movement) {
    const movements = getMovements();
    movements.unshift(movement);
    return setMovements(movements);
}

export function updateMovement(id, changes) {
    const movements = getMovements();
    const index = movements.findIndex(item => String(item.id) === String(id));
    if (index === -1) return false;
    movements[index] = { ...movements[index], ...changes };
    return setMovements(movements);
}

export function deleteMovement(id) {
    return setMovements(
        getMovements().filter(item => String(item.id) !== String(id))
    );
}

/* NUEVA FUNCIÓN PARA OPTIMIZAR BORRADOS MASIVOS O(N*M) -> O(N) EN I/O */
export function deleteMovements(ids) {
    const idSet = new Set(ids.map(id => String(id)));
    return setMovements(
        getMovements().filter(item => !idSet.has(String(item.id)))
    );
}

export function getGoals() {
    const data = getItem(STORAGE_KEYS.GOALS);
    return Array.isArray(data) ? data : [];
}

export function setGoals(goals) {
    return Array.isArray(goals) && setItem(STORAGE_KEYS.GOALS, goals);
}

export function addGoal(goal) {
    const goals = getGoals();
    goals.unshift(goal);
    return setGoals(goals);
}

export function updateGoal(id, changes) {
    const goals = getGoals();
    const index = goals.findIndex(item => String(item.id) === String(id));
    if (index === -1) return false;
    goals[index] = { ...goals[index], ...changes };
    return setGoals(goals);
}

export function deleteGoal(id) {
    return setGoals(
        getGoals().filter(item => String(item.id) !== String(id))
    );
}

export function getSettings() {
    return getItem(STORAGE_KEYS.SETTINGS) || {};
}

export function setSettings(settings) {
    return setItem(STORAGE_KEYS.SETTINGS, settings);
}

export function clearAppData() {
    let success = true;

    Object.values(STORAGE_KEYS).forEach(key => {
        success = removeItem(key) && success;
        success = removeItem(key, true) && success;
    });

    return success;
}