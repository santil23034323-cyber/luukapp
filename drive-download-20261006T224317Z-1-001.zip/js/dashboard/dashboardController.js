/* =========================================================
   LukApp · dashboardController.js
   ========================================================= */

import { ensureDemoData } from '../../data/demoData.js';
import { getDashboardData } from './dashboardModel.js';
import { renderDashboard } from './dashboardView.js';

document.addEventListener('DOMContentLoaded', initializeDashboard);

document.addEventListener('lukapp:user-updated', () => {
    renderDashboard(getDashboardData());
});

function initializeDashboard() {
    ensureDemoData();
    renderDashboard(getDashboardData());

    document.getElementById('btnAgregarMovimiento')?.addEventListener('click', () => {
        window.location.href = 'movimientos.html?action=new';
    });
}