/* =========================================================
   LukApp · authController.js
   ========================================================= */

import { login, isAuthenticated } from './authModel.js';
import {
    getLoginFormData,
    setLoading,
    showMessage,
    clearMessage,
    togglePasswordVisibility
} from './authView.js';

const DEMO_MODE = true;

function initializeAuth() {
    const form = document.getElementById('loginForm');
    if (!form) return;

    if (isAuthenticated()) {
        window.location.replace('dashboard.html');
        return;
    }

    form.addEventListener('submit', handleLogin);

    document.getElementById('btnTogglePassword')?.addEventListener('click', togglePasswordVisibility);

    document.getElementById('btnForgotPassword')?.addEventListener('click', () => {
        showMessage('La recuperación estará disponible cuando conectemos el servicio de autenticación.', 'info');
    });

    document.getElementById('btnRegister')?.addEventListener('click', () => {
        showMessage('El registro se habilitará con el módulo de cuentas.', 'info');
    });

    document.getElementById('btnGoogleLogin')?.addEventListener('click', () => {
        showMessage('El acceso con Google requiere integración con el servicio de autenticación.', 'info');
    });

    if (DEMO_MODE) {
        const email = document.getElementById('userEmail');
        const password = document.getElementById('userPassword');
        if (email && !email.value) email.value = 'usuario@lukapp.com';
        if (password && !password.value) password.value = '123456';
    }
}

async function handleLogin(event) {
    event.preventDefault();
    clearMessage();

    const { email, password, remember } = getLoginFormData();

    if (!email) {
        showMessage('Ingresa tu correo electrónico.');
        return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showMessage('Ingresa un correo electrónico válido.');
        return;
    }

    if (!password) {
        showMessage('Ingresa tu contraseña.');
        return;
    }

    setLoading(true);
    await wait(350);

    const result = await login(email, password, remember);

    if (!result.success) {
        setLoading(false);
        showMessage(result.message);
        return;
    }

    showMessage('Sesión iniciada. Redirigiendo...', 'success');
    await wait(250);
    window.location.replace('dashboard.html');
}

function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

document.addEventListener('DOMContentLoaded', initializeAuth);
