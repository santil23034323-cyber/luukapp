/* =========================================================
   LukApp · authModel.js
   Autenticación local para modo frontend.
   ========================================================= */

import {
    getItem,
    setItem, // 1. Agregada la importación de setItem
    getCurrentUser,
    setCurrentUser,
    setSession,
    getSession,
    clearSession,
    STORAGE_KEYS
} from '../services/storageService.js';

import { hashString } from '../services/cryptoService.js';

const DEFAULT_PASSWORD = '123456';

const DEFAULT_USER = {
    id: 1,
    name: 'Daniel',
    lastName: 'Gutiérrez',
    email: 'usuario@lukapp.com',
    plan: 'Premium',
    avatar: null
};

export async function login(email, password, remember = true) {
    const user = getCurrentUser() || DEFAULT_USER;
    const settings = getItem(STORAGE_KEYS.SETTINGS) || {};

    let passwordHash = settings.security?.passwordHash;

    if (!passwordHash) {
        passwordHash = await hashString(DEFAULT_PASSWORD);
        const nextSettings = {
            ...settings,
            security: {
                ...(settings.security || {}),
                passwordHash
            }
        };
        // 2. Corregido: Se guarda la configuración en el storageService local en vez de buscar un 'data.token' inexistente
        setItem(STORAGE_KEYS.SETTINGS, nextSettings);
    }

    const suppliedHash = await hashString(password);
    const emailValid = email.trim().toLowerCase() === user.email.trim().toLowerCase();
    const passwordValid = suppliedHash === passwordHash;

    if (!emailValid || !passwordValid) {
        return {
            success: false,
            message: 'El correo o la contraseña no son correctos.'
        };
    }

    setCurrentUser(user, remember);
    setSession({
        authenticated: true,
        userId: user.id,
        createdAt: new Date().toISOString()
    }, remember);

    return { success: true, user };
}

export function isAuthenticated() {
    return Boolean(getSession());
}

export function logout() {
    clearSession();
}