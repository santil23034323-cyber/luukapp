/* =========================================================
   LukApp · configuracionModel.js
   ========================================================= */

import {
    getItem,
    setItem,
    removeItem,
    getCurrentUser,
    setCurrentUser,
    clearSession,
    clearAppData,
    STORAGE_KEYS
} from '../services/storageService.js';

import { hashString } from '../services/cryptoService.js';

const DEFAULT_SETTINGS = {
    currency: 'COP',
    notifications: {
        financialSummary: true,
        goals: true,
        spendingAlerts: true,
        updates: false
    },
    appearance: {
        theme: 'light',
        animations: true
    },
    security: {
        twoFactorEnabled: false,
        passwordHash: null
    }
};

const DEFAULT_PASSWORD = '123456';

export function getSettings() {
    return mergeSettings(DEFAULT_SETTINGS, getItem(STORAGE_KEYS.SETTINGS) || {});
}

export function saveSettings(settings) {
    return setItem(STORAGE_KEYS.SETTINGS, mergeSettings(getSettings(), settings));
}

export function getProfile() {
    return getCurrentUser() || {
        id: 1,
        name: 'Daniel',
        lastName: 'Gutiérrez',
        email: 'usuario@lukapp.com',
        plan: 'Premium',
        avatar: null
    };
}

export function saveProfile(changes) {
    return setCurrentUser({ ...getProfile(), ...changes }, true);
}

export function updateNotificationSetting(key, value) {
    const settings = getSettings();
    if (!(key in settings.notifications)) return false;
    settings.notifications[key] = Boolean(value);
    return saveSettings(settings);
}

export function updateAppearanceSetting(key, value) {
    const settings = getSettings();
    if (!(key in settings.appearance)) return false;
    settings.appearance[key] = value;
    return saveSettings(settings);
}

export function updateCurrency(currency) {
    return saveSettings({ currency });
}

export async function validateCurrentPassword(password) {
    const settings = getSettings();
    let hash = settings.security.passwordHash;

    if (!hash) {
        hash = await hashString(DEFAULT_PASSWORD);
        saveSettings({ security: { passwordHash: hash } });
    }

    return (await hashString(password)) === hash;
}

export async function changePassword(currentPassword, newPassword) {
    if (!(await validateCurrentPassword(currentPassword))) {
        return { success: false, message: 'La contraseña actual no es correcta.' };
    }

    const passwordHash = await hashString(newPassword);
    const saved = saveSettings({ security: { passwordHash } });

    return {
        success: saved,
        message: saved ? 'Contraseña actualizada correctamente.' : 'No fue posible guardar la contraseña.'
    };
}

export function setTwoFactorEnabled(enabled) {
    return saveSettings({ security: { twoFactorEnabled: Boolean(enabled) } });
}

export function deleteLocalAccount() {
    return clearAppData();
}

function mergeSettings(base, override) {
    return {
        ...base,
        ...override,
        notifications: { ...base.notifications, ...(override.notifications || {}) },
        appearance: { ...base.appearance, ...(override.appearance || {}) },
        security: { ...base.security, ...(override.security || {}) }
    };
}
