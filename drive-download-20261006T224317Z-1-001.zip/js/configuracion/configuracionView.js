/* =========================================================
   LukApp · configuracionView.js
   ========================================================= */

export function initializeTabs() {
    document.querySelectorAll('[data-section]').forEach(button => {
        button.addEventListener('click', () => setActiveSection(button.dataset.section));
    });
}

export function setActiveSection(section) {
    document.querySelectorAll('[data-section]').forEach(button => {
        const active = button.dataset.section === section;
        button.classList.toggle('active', active);
        button.setAttribute('aria-selected', String(active));
    });

    document.querySelectorAll('[id^="section-"]').forEach(element => {
        element.hidden = element.id !== `section-${section}`;
    });
}

export function fillProfile(user, currency) {
    setValue(['#profileName', '#userNameInput', '[name="name"]'], user.name);
    setValue(['#profileLastName', '#profileSurname', '#userLastNameInput', '[name="lastName"]'], user.lastName);
    setValue(['#profileEmail', '#userEmailInput', '[name="email"]'], user.email);
    setValue(['#profileCurrency', '#currency', '[name="currency"]'], currency);
    updateAvatar(user.avatar, user);
}

export function getProfileData() {
    return {
        name: getValue(['#profileName', '#userNameInput', '[name="name"]']),
        lastName: getValue(['#profileLastName', '#profileSurname', '#userLastNameInput', '[name="lastName"]']),
        email: getValue(['#profileEmail', '#userEmailInput', '[name="email"]']),
        currency: getValue(['#profileCurrency', '#currency', '[name="currency"]']) || 'COP'
    };
}

export function updateAvatar(avatar, user) {
    // Abarcamos todos los selectores del Layout general y de configuración
    const elements = document.querySelectorAll('#profileAvatar, .profile-avatar, .settings-avatar, .topbar-avatar, .user-avatar');
    elements.forEach(element => {
        if (element.tagName === 'IMG') {
            if (avatar) {
                element.src = avatar;
            } else {
                element.removeAttribute('src');
            }
        } else {
            if (avatar) {
                element.style.backgroundImage = `url("${avatar}")`;
                element.style.backgroundSize = 'cover';
                element.style.backgroundPosition = 'center';
                element.textContent = '';
            } else {
                element.style.backgroundImage = '';
                element.textContent = `${user.name?.charAt(0) || ''}${user.lastName?.charAt(0) || ''}`.toUpperCase() || 'U';
            }
        }
    });
}

export function getSecurityData() {
    return {
        currentPassword: getValue(['#currentPassword', '[name="currentPassword"]'], false),
        newPassword: getValue(['#newPassword', '[name="newPassword"]'], false),
        confirmPassword: getValue(['#confirmPassword', '#confirmNewPassword', '[name="confirmPassword"]'], false)
    };
}

export function clearPasswordFields() {
    ['#currentPassword', '#newPassword', '#confirmPassword', '#confirmNewPassword'].forEach(selector => {
        const element = document.querySelector(selector);
        if (element) element.value = '';
    });
}

export function setSettingValue(setting, value) {
    const element = findSettingElement(setting);
    if (!element) return;

    if (element.matches('input[type="checkbox"]')) {
        element.checked = Boolean(value);
    } else {
        element.setAttribute('aria-checked', String(Boolean(value)));
        element.classList.toggle('active', Boolean(value));
    }
}

export function getSettingValue(setting) {
    const element = findSettingElement(setting);
    if (!element) return false;
    if (element.matches('input[type="checkbox"]')) return element.checked;
    return element.getAttribute('aria-checked') === 'true';
}

export function setThemeSelection(theme) {
    document.querySelectorAll('input[name="theme"]').forEach(input => {
        input.checked = input.value === theme;
    });
}

export function showFeedback(message, type = 'success', sectionId = 'section-perfil') {
    const section = document.getElementById(sectionId);
    if (!section) return;

    let box = section.querySelector('.config-feedback');
    if (!box) {
        box = document.createElement('div');
        section.prepend(box);
    }

    box.className = `form-message ${type} config-feedback`;
    box.textContent = message;

    clearTimeout(box._timeout);
    box._timeout = setTimeout(() => box.remove(), 3500);
}

function findElement(selectors) {
    for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) return element;
    }
    return null;
}

function setValue(selectors, value) {
    const element = findElement(selectors);
    if (element) element.value = value ?? '';
}

function getValue(selectors, trim = true) {
    const element = findElement(selectors);
    if (!element) return '';
    return trim ? element.value.trim() : element.value;
}

function findSettingElement(setting) {
    const selectorMap = {
        financialSummary: ['#toggleFinancialSummary', '#toggleResumenFinanciero', '[data-setting="financialSummary"]'],
        goals: ['#toggleGoals', '#toggleMetas', '[data-setting="goals"]'],
        spendingAlerts: ['#toggleSpendingAlerts', '#toggleAlertasGasto', '[data-setting="spendingAlerts"]'],
        updates: ['#toggleUpdates', '#toggleNovedades', '[data-setting="updates"]'],
        twoFactorEnabled: ['#twoFactorToggle', '[data-setting="twoFactorEnabled"]'],
        animations: ['#toggleAnimations', '#toggleAnimaciones', '[data-setting="animations"]']
    };
    return findElement(selectorMap[setting] || []);
}