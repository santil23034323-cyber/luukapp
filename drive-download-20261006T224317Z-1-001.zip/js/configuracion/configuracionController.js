import '../core/app.js';
/* =========================================================
   LukApp · configuracionController.js
   ========================================================= */

import { getSettings, saveProfile, updateNotificationSetting, updateAppearanceSetting, updateCurrency, changePassword, setTwoFactorEnabled, deleteLocalAccount, getProfile } from './configuracionModel.js';
import { applyTheme } from '../core/theme.js';
import { initializeTabs, setActiveSection, fillProfile, getProfileData, updateAvatar, getSecurityData, clearPasswordFields, setSettingValue, getSettingValue, setThemeSelection, showFeedback } from './configuracionView.js';

function initializeConfiguration() {
    const settings = getSettings();
    const user = getProfile();

    initializeTabs();
    initializeProfile(user, settings);
    initializeSecurity(settings);
    initializeNotifications(settings);
    initializeAppearance(settings);
    setActiveSection(document.querySelector('[data-section].active')?.dataset.section || 'perfil');
}

document.addEventListener('DOMContentLoaded', initializeConfiguration);

function initializeProfile(user, settings) {
    fillProfile(user, settings.currency);

    const form = document.getElementById('profileForm') || document.querySelector('#section-perfil form');
    form?.addEventListener('submit', event => {
        event.preventDefault();
        const data = getProfileData();

        if (!data.name || !data.lastName) {
            showFeedback('Nombre y apellido son obligatorios.', 'error');
            return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            showFeedback('Ingresa un correo electrónico válido.', 'error');
            return;
        }

        const profileSaved = saveProfile({ name: data.name, lastName: data.lastName, email: data.email });
        const currencySaved = updateCurrency(data.currency);

        if (profileSaved && currencySaved) {
            fillProfile(getProfile(), getSettings().currency);
            showFeedback('Perfil actualizado correctamente.', 'success');
            document.dispatchEvent(new CustomEvent('lukapp:user-updated', { detail: getProfile() }));
        }
    });

    document.getElementById('btnCancelProfile')?.addEventListener('click', () => {
        fillProfile(getProfile(), getSettings().currency);
        showFeedback('Cambios descartados.', 'info');
    });

    document.getElementById('btnChangePhoto')?.addEventListener('click', selectAvatar);
    document.getElementById('btnRemovePhoto')?.addEventListener('click', () => {
        if (saveProfile({ avatar: null })) {
            updateAvatar(null, getProfile());
            showFeedback('Foto de perfil eliminada.', 'success');
        }
    });
}

function selectAvatar() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp';
    input.hidden = true;

    input.addEventListener('change', () => {
        const file = input.files?.[0];
        if (!file) return input.remove();

        if (file.size > 2 * 1024 * 1024) {
            showFeedback('La imagen no puede superar 2 MB.', 'error');
            input.remove();
            return;
        }

        const reader = new FileReader();
        reader.addEventListener('load', () => {
            const avatar = reader.result;
            if (saveProfile({ avatar })) {
                updateAvatar(avatar, getProfile());
                showFeedback('Foto de perfil actualizada.', 'success');
            }
            input.remove();
        });
        reader.readAsDataURL(file);
    });

    document.body.appendChild(input);
    input.click();
}

function initializeSecurity(settings) {
    const form = document.getElementById('securityForm') || document.querySelector('#section-seguridad form');
    form?.addEventListener('submit', handlePasswordChange);

    document.querySelectorAll('[data-password-toggle]').forEach(button => {
        const input = document.getElementById(button.dataset.passwordToggle);
        if (!input) return;
        button.addEventListener('click', () => {
            const visible = input.type === 'text';
            input.type = visible ? 'password' : 'text';
            button.textContent = visible ? 'Mostrar' : 'Ocultar';
        });
    });

    setSettingValue('twoFactorEnabled', settings.security.twoFactorEnabled);
    const twoFactor = findSettingElement('twoFactorEnabled');
    twoFactor?.addEventListener('change', event => {
        setTwoFactorEnabled(event.target.checked);
        showFeedback(event.target.checked ? 'Autenticación en dos pasos activada.' : 'Autenticación en dos pasos desactivada.', 'success', 'section-seguridad');
    });

    document.getElementById('btnDeleteAccount')?.addEventListener('click', () => {
        if (!confirm('¿Eliminar los datos locales de LukApp? Esta acción no se puede deshacer.')) return;
        deleteLocalAccount();
        window.location.replace('login.html');
    });
}

async function handlePasswordChange(event) {
    event.preventDefault();
    const { currentPassword, newPassword, confirmPassword } = getSecurityData();

    if (!currentPassword) return showFeedback('Ingresa la contraseña actual.', 'error', 'section-seguridad');
    if (newPassword.length < 8) return showFeedback('La nueva contraseña debe tener mínimo 8 caracteres.', 'error', 'section-seguridad');
    if (newPassword !== confirmPassword) return showFeedback('Las nuevas contraseñas no coinciden.', 'error', 'section-seguridad');

    const result = await changePassword(currentPassword, newPassword);
    if (!result.success) return showFeedback(result.message, 'error', 'section-seguridad');

    clearPasswordFields();
    showFeedback(result.message, 'success', 'section-seguridad');
}

function initializeNotifications(settings) {
    Object.entries(settings.notifications).forEach(([key, value]) => {
        setSettingValue(key, value);
        const element = findSettingElement(key);
        if (!element || element.dataset.bound) return;
        element.dataset.bound = 'true';
        element.addEventListener('change', () => updateNotificationSetting(key, getSettingValue(key)));
    });
}

function initializeAppearance(settings) {
    applyTheme(settings.appearance.theme);
    setThemeSelection(settings.appearance.theme);

    document.querySelectorAll('input[name="theme"]').forEach(input => {
        input.addEventListener('change', () => {
            if (!input.checked) return;
            applyTheme(input.value);
            updateAppearanceSetting('theme', input.value);
        });
    });

    setSettingValue('animations', settings.appearance.animations);
    const animations = findSettingElement('animations');
    animations?.addEventListener('change', () => {
        const enabled = getSettingValue('animations');
        updateAppearanceSetting('animations', enabled);
        document.documentElement.dataset.animations = enabled ? 'on' : 'off';
    });

    document.documentElement.dataset.animations = settings.appearance.animations ? 'on' : 'off';
}

function findElement(selectors) {
    for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) return element;
    }
    return null;
}

function findSettingElement(setting) {
    const map = {
        financialSummary: ['#toggleFinancialSummary', '#toggleResumenFinanciero', '[data-setting="financialSummary"]'],
        goals: ['#toggleGoals', '#toggleMetas', '[data-setting="goals"]'],
        spendingAlerts: ['#toggleSpendingAlerts', '#toggleAlertasGasto', '[data-setting="spendingAlerts"]'],
        updates: ['#toggleUpdates', '#toggleNovedades', '[data-setting="updates"]'],
        twoFactorEnabled: ['#twoFactorToggle', '[data-setting="twoFactorEnabled"]'],
        animations: ['#toggleAnimations', '#toggleAnimaciones', '[data-setting="animations"]']
    };
    return findElement(map[setting] || []);
}
