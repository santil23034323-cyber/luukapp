import '../core/app.js';
/* =========================================================
   LukApp · metaController.js
   ========================================================= */

import { getAllGoals, getGoalById, createGoal, editGoal, contributeToGoal, removeGoal, getGoalSummary } from './metaModel.js';
import { renderSummary, renderGoals, openGoalModal, closeGoalModal, getGoalFormData, promptContribution } from './metaView.js';
import { notifyGoalReached, createNotification } from '../services/notificationService.js';

let goals = [];

document.addEventListener('DOMContentLoaded', initializeGoals);

document.addEventListener('lukapp:data-changed', render);

function initializeGoals() {
    load();

    document.getElementById('btnNuevaMeta')?.addEventListener('click', () => showForm());
    document.getElementById('metasGridContainer')?.addEventListener('click', handleGoalAction);

    render();
}

function load() {
    goals = getAllGoals();
}

function render() {
    load();
    renderSummary(getGoalSummary(goals), goals.length);
    renderGoals(goals);
}

function showForm(goal = null) {
    const form = openGoalModal(goal);
    if (!form) return;

    form.addEventListener('submit', event => {
        event.preventDefault();
        const data = getGoalFormData(form);

        if (!data.name || Number(data.target) <= 0) {
            alert('Completa el nombre y un objetivo válido.');
            return;
        }

        // LÓGICA CORREGIDA: Removida la restricción que bloqueaba que el usuario
        // guardara una meta con un monto que haya excedido su objetivo.
        if (goal) editGoal(goal.id, data);
        else createGoal(data);

        closeGoalModal();
        render();
        emitDataChanged();
    }, { once: true });

    form.querySelector('#deleteGoalButton')?.addEventListener('click', () => {
        if (confirm('¿Eliminar esta meta?')) {
            removeGoal(goal.id);
            closeGoalModal();
            render();
            emitDataChanged();
        }
    });
}

function handleGoalAction(event) {
    const button = event.target.closest('[data-goal-action]');
    if (!button) return;

    const id = button.dataset.id;
    const goal = getGoalById(id);
    if (!goal) return;

    const action = button.dataset.goalAction;

    if (action === 'edit') showForm(goal);

    if (action === 'contribute') {
        const amount = promptContribution(goal);
        if (amount === null) return;
        
        // Determinar estado previo para solo notificar si se cruzó la barrera en este evento
        const wasCompleted = Number(goal.saved) >= Number(goal.target);
        
        const updated = contributeToGoal(id, amount);
        if (!updated) return;

        // Solo notificar si la meta se completó justo ahora, evitando spam de excedentes
        if (!wasCompleted && updated.saved >= updated.target) {
            notifyGoalReached(updated.name);
            createNotification({ title: 'Excelente progreso', message: `Completaste "${updated.name}".`, type: 'success' });
        }

        render();
        emitDataChanged();
    }

    if (action === 'menu') showForm(goal);
}

function emitDataChanged() {
    document.dispatchEvent(new CustomEvent('lukapp:data-changed'));
}