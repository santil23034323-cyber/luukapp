/* =========================================================
   LukApp · metaModel.js
   ========================================================= */

import {
    getGoals,
    addGoal,
    updateGoal,
    deleteGoal
} from '../services/storageService.js';

export function getAllGoals() {
    return [...getGoals()];
}

export function getGoalById(id) {
    return getAllGoals().find(goal => String(goal.id) === String(id)) || null;
}

export function createGoal(data) {
    const goal = {
        id: crypto.randomUUID?.() || `goal-${Date.now()}`,
        name: data.name,
        icon: data.icon || '◎',
        target: Number(data.target),
        saved: Number(data.saved || 0),
        deadline: data.deadline || '',
        color: data.color || 'var(--primary-color)'
    };

    return addGoal(goal) ? goal : null;
}

export function editGoal(id, data) {
    return updateGoal(id, {
        name: data.name,
        icon: data.icon,
        target: Number(data.target),
        saved: Number(data.saved || 0),
        deadline: data.deadline,
        color: data.color
    });
}

export function contributeToGoal(id, amount) {
    const goal = getGoalById(id);
    if (!goal) return null;

    // LÓGICA CORREGIDA: Se elimina la restricción de Math.min.
    // El usuario puede ahorrar más de su objetivo si lo desea sin perder el registro del dinero.
    const nextSaved = Number(goal.saved || 0) + Number(amount);
    updateGoal(id, { saved: nextSaved });

    return { ...goal, saved: nextSaved };
}

export function removeGoal(id) {
    return deleteGoal(id);
}

export function getGoalSummary(goals = getAllGoals()) {
    const saved = goals.reduce((sum, goal) => sum + Number(goal.saved || 0), 0);
    const target = goals.reduce((sum, goal) => sum + Number(goal.target || 0), 0);
    const progress = target ? (saved / target) * 100 : 0;

    return {
        saved,
        target,
        progress: Math.min(100, progress)
    };
}