/* =========================================================
   LukApp · metaView.js
   ========================================================= */

export function renderSummary(summary, count) {
    setText('kpiAhorradoTotal', currency(summary.saved));
    setText('kpiObjetivoTotal', currency(summary.target));
    setText('kpiProgresoGlobal', `${summary.progress.toFixed(1)}%`);
    setText('metasSummaryText', `${count} ${count === 1 ? 'meta registrada' : 'metas registradas'}`);
}

export function renderGoals(goals) {
    const container = document.getElementById('metasGridContainer');
    if (!container) return;

    if (!goals.length) {
        container.innerHTML = '<div class="empty-state">Aún no tienes metas. Crea la primera desde “Nueva meta”.</div>';
        return;
    }

    let html = '';
    goals.forEach(goal => {
        const percentage = Math.min(100, (Number(goal.saved) / Number(goal.target || 1)) * 100);
        const isCompleted = percentage >= 100;
        const remaining = Number(goal.target) - Number(goal.saved);

        html += `
            <article class="meta-card ${isCompleted ? 'meta-card--completed' : 'meta-card--primary'}" style="--meta-color: ${escapeAttr(goal.color || 'var(--primary-color)')}">
                <header class="meta-card__header">
                    <span class="meta-card__icon">${escapeHTML(goal.icon || '◎')}</span>
                    <div class="meta-card__heading">
                        <h3 class="meta-card__title">${escapeHTML(goal.name)}</h3>
                        <span class="meta-card__deadline">${goal.deadline ? `Límite: ${formatDate(goal.deadline)}` : 'Sin fecha'}</span>
                    </div>
                    ${isCompleted ? '<span class="meta-card__badge">✓ Completada</span>' : ''}
                </header>
                <p class="meta-card__amount">
                    <strong class="mono">${currency(goal.saved)}</strong>
                    <span>de ${currency(goal.target)}</span>
                </p>
                <div class="progress-track">
                    <div class="progress-fill" style="width:${percentage}%"></div>
                </div>
                <div class="meta-card__progress">
                    <span class="meta-card__percent">${percentage.toFixed(0)}%</span>
                    ${!isCompleted ? `<span class="meta-card__remaining">Faltan ${currency(remaining)}</span>` : '<span class="meta-card__remaining">¡Meta alcanzada!</span>'}
                </div>
                <footer class="meta-card__actions">
                    <button type="button" class="btn-primary" data-goal-action="contribute" data-id="${escapeAttr(goal.id)}">Abonar</button>
                    <button type="button" class="btn-secondary" data-goal-action="edit" data-id="${escapeAttr(goal.id)}">Editar</button>
                </footer>
            </article>
        `;
    });
    
    // Inserción única y eficiente en el DOM (O(1) mutaciones)
    container.innerHTML = html;
}

export function openGoalModal(goal = null) {
    closeGoalModal();

    const modal = document.createElement('div');
    modal.className = 'modal-backdrop';
    modal.id = 'goalModal';
    modal.innerHTML = `
        <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="goalModalTitle">
            <div class="modal-header">
                <div><span class="section-eyebrow">Planificación</span><h2 id="goalModalTitle">${goal ? 'Editar meta' : 'Nueva meta'}</h2></div>
                <button type="button" class="btn-icon-sm" id="closeGoalModal" aria-label="Cerrar">×</button>
            </div>
            <form id="goalForm" class="modal-form">
                <div class="modal-grid">
                    <div class="input-group"><label for="goalName">Nombre</label><input id="goalName" name="name" maxlength="70" required value="${escapeAttr(goal?.name || '')}" placeholder="Ej. Viaje"></div>
                    <div class="input-group"><label for="goalIcon">Icono</label><input id="goalIcon" name="icon" maxlength="2" value="${escapeAttr(goal?.icon || '◎')}" placeholder="◎"></div>
                </div>
                <div class="modal-grid">
                    <div class="input-group"><label for="goalTarget">Objetivo</label><input id="goalTarget" name="target" type="number" min="1" step="1" required value="${escapeAttr(goal?.target || '')}"></div>
                    <div class="input-group"><label for="goalSaved">Ahorrado</label><input id="goalSaved" name="saved" type="number" min="0" step="1" value="${escapeAttr(goal?.saved || 0)}"></div>
                </div>
                <div class="input-group"><label for="goalDeadline">Fecha objetivo</label><input id="goalDeadline" name="deadline" type="date" value="${escapeAttr(goal?.deadline || '')}"></div>
                <div class="modal-actions">
                    ${goal ? '<button type="button" class="btn-danger-outline" id="deleteGoalButton">Eliminar</button>' : ''}
                    <span></span>
                    <button type="button" class="btn-secondary" id="cancelGoalModal">Cancelar</button>
                    <button type="submit" class="btn-primary">${goal ? 'Guardar cambios' : 'Crear meta'}</button>
                </div>
            </form>
        </div>
    `;

    document.body.appendChild(modal);
    modal.querySelector('#closeGoalModal').addEventListener('click', closeGoalModal);
    modal.querySelector('#cancelGoalModal').addEventListener('click', closeGoalModal);
    modal.addEventListener('click', event => { if (event.target === modal) closeGoalModal(); });

    return modal.querySelector('#goalForm');
}

export function closeGoalModal() {
    document.getElementById('goalModal')?.remove();
}

export function getGoalFormData(form) {
    return Object.fromEntries(new FormData(form).entries());
}

export function promptContribution(goal) {
    const raw = window.prompt(`¿Cuánto deseas aportar a "${goal.name}"?`, '100000');
    if (raw === null) return null;
    const amount = Number(raw);
    if (!Number.isFinite(amount) || amount <= 0) {
        alert('Ingresa un monto válido.');
        return null;
    }
    return amount;
}

function currency(value) {
    return Number(value || 0).toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });
}

function formatDate(value) {
    return new Date(value + 'T00:00:00').toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' });
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function escapeHTML(value) {
    return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}

function escapeAttr(value) { return escapeHTML(value); }